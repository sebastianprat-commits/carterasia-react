function Formacion() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Formación Financiera</h2>
      <p>Aquí encontrarás recursos para aprender a invertir de forma inteligente.</p>
    </div>
  )
}

export default Formacion
