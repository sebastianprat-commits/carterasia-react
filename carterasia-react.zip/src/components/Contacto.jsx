function Contacto() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Contáctanos</h2>
      <p>Para dudas o asesoría personalizada, escríbenos a contacto@carterasIA.com</p>
    </div>
  )
}

export default Contacto
